/**
 * AI工作区主脚本
 * 提供基本功能和界面交互
 */

document.addEventListener('DOMContentLoaded', function() {
    // 设置年份
    document.getElementById('year').textContent = new Date().getFullYear();
    
    // 初始化系统状态进度条
    initSystemStatus();
    
    // 设置按钮事件
    setupButtons();
    
    // 初始化数据存储
    setupStorage();
    
    // 添加页面过渡动画
    addPageTransition();
});

/**
 * 初始化系统状态进度条
 */
function initSystemStatus() {
    const progressBar = document.getElementById('system-progress');
    const progressText = document.getElementById('progress-percent');
    
    let width = 0;
    const interval = setInterval(() => {
        if (width >= 100) {
            clearInterval(interval);
            progressText.textContent = '100%';
        } else {
            width += Math.random() * 5;
            if (width > 100) width = 100;
            progressBar.style.width = width + '%';
            progressText.textContent = Math.round(width) + '%';
        }
    }, 100);
}

/**
 * 设置按钮事件
 */
function setupButtons() {
    const actionButton = document.getElementById('action-button');
    
    actionButton.addEventListener('click', function() {
        this.disabled = true;
        this.textContent = '诊断中...';
        
        setTimeout(() => {
            runSystemCheck();
        }, 300);
    });
}

/**
 * 运行系统诊断
 */
function runSystemCheck() {
    const checks = [
        '检查系统状态...',
        '验证数据完整性...',
        '连接测试...',
        '环境分析...',
        '全部正常'
    ];
    
    let step = 0;
    const savedContent = document.getElementById('saved-content');
    const originalContent = savedContent.textContent;
    
    const interval = setInterval(() => {
        if (step >= checks.length) {
            clearInterval(interval);
            savedContent.textContent = originalContent;
            
            const actionButton = document.getElementById('action-button');
            actionButton.textContent = '运行诊断';
            actionButton.disabled = false;
            
            showNotification('系统诊断完成', 'success');
            return;
        }
        
        savedContent.textContent = checks[step];
        step++;
    }, 800);
}

/**
 * 初始化本地存储系统
 */
function setupStorage() {
    const storageInput = document.getElementById('storage-input');
    const saveBtn = document.getElementById('save-btn');
    const clearBtn = document.getElementById('clear-btn');
    const savedContent = document.getElementById('saved-content');
    const savedTime = document.getElementById('saved-time');
    const storageIndicator = document.getElementById('storage-indicator');
    
    // 页面加载时读取已保存的数据
    loadSavedData();
    
    // 保存按钮点击事件
    saveBtn.addEventListener('click', function() {
        const text = storageInput.value.trim();
        if (text) {
            try {
                // 保存数据和时间戳到localStorage
                const data = {
                    content: text,
                    timestamp: new Date().toLocaleString()
                };
                
                localStorage.setItem('savedData', JSON.stringify(data));
                
                // 更新显示
                loadSavedData();
                storageInput.value = '';
                
                // 添加成功提示
                showNotification('数据已保存', 'success');
            } catch (e) {
                console.error('localStorage保存失败:', e);
                showNotification('保存失败: ' + e.message, 'error');
            }
        } else {
            showNotification('请输入内容后再保存', 'warning');
        }
    });
    
    // 清除按钮点击事件
    clearBtn.addEventListener('click', function() {
        try {
            localStorage.removeItem('savedData');
            savedContent.textContent = '无数据';
            savedTime.textContent = '无';
            storageIndicator.classList.remove('active');
            
            showNotification('数据已清除', 'success');
        } catch (e) {
            console.error('localStorage清除失败:', e);
            showNotification('清除失败: ' + e.message, 'error');
        }
    });
}

/**
 * 读取已保存的数据
 */
function loadSavedData() {
    try {
        const savedData = localStorage.getItem('savedData');
        const savedContent = document.getElementById('saved-content');
        const savedTime = document.getElementById('saved-time');
        const storageIndicator = document.getElementById('storage-indicator');
        
        if (savedData) {
            const data = JSON.parse(savedData);
            savedContent.textContent = data.content || '无数据';
            savedTime.textContent = data.timestamp || '无';
            storageIndicator.classList.add('active');
        } else {
            savedContent.textContent = '无数据';
            savedTime.textContent = '无';
            storageIndicator.classList.remove('active');
        }
    } catch (e) {
        console.error('读取localStorage数据失败:', e);
        document.getElementById('saved-content').textContent = '读取失败';
    }
}

/**
 * 显示通知消息
 * @param {string} message - 通知消息
 * @param {string} type - 通知类型 (success, error, warning)
 */
function showNotification(message, type) {
    // 检查是否已有通知，如果有则移除
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        document.body.removeChild(existingNotification);
    }
    
    // 创建通知元素
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // 添加到页面
    document.body.appendChild(notification);
    
    // 动画效果
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // 3秒后移除
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentElement) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

/**
 * 添加页面过渡动画
 */
function addPageTransition() {
    const content = document.querySelector('.content');
    if (!content) return;
    
    // 添加卡片动画
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100 + (index * 100));
    });
} 